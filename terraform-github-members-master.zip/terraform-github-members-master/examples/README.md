
# Example and manual test cases

Each directory contains a configuration that serves as a manual test case and an example
