# Other Terraform modules using this

List of other Terraform modules using this one or that have examples (test cases)
that use this module.

These can also serve as more examples


| Name | GitHub Repo | Terraform Registry |
|-----|-----|-----|
| team-members | [Repo](https://github.com/devops-workflow/terraform-github-team-members) | [Registry](https://registry.terraform.io/modules/devops-workflow/team-members/github) |
